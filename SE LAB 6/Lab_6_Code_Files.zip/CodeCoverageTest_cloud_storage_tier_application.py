import pytest

from cloud_storage_tier import monitor_replication_latency, process_storage_tenants


@pytest.mark.parametrize(
    ("tenants", "support_fee"),
    [
        (None, 0.0),
        ([], -0.01),
    ],
)
def test_invalid_input_is_rejected(tenants, support_fee):
    with pytest.raises(ValueError, match="Invalid tenants list or support fee"):
        process_storage_tenants(tenants, support_fee)


def test_storage_tiers_flags_discounts_egress_and_backup_fee():
    tenants = [
        {
            "account_active": False,
            "tier": "hot",
            "buckets": [{"size_gb": 500, "egress_gb": 150}],
        },
        {
            "account_active": True,
            "tier": "hot",
            "buckets": [
                {"size_gb": 100, "egress_gb": 150},
                {"size_gb": 0, "egress_gb": 150},
                {"size_gb": 10, "corrupted": True, "egress_gb": 150},
            ],
        },
        {
            "account_active": True,
            "tier": "cool",
            "buckets": [{"size_gb": 501, "egress_gb": 105}],
        },
        {
            "account_active": True,
            "tier": "archive",
            "buckets": [{"size_gb": 200, "egress_gb": 101}],
        },
        {
            "account_active": True,
            "tier": "archive",
            "has_backup_vault": True,
            "buckets": [{"size_gb": 20, "corrupted": True, "egress_gb": 200}],
        },
        {"account_active": True, "tier": "cold-storage", "buckets": []},
        {"account_active": True, "buckets": []},
    ]

    result = process_storage_tenants(tenants, fixed_support_fee=10.0)

    # The archive corruption resets storage charges, while the vault fee still applies.
    assert result == {"total_billed": 28.74, "status": "BILLED"}


def test_audit_flag_and_zero_usage_statuses():
    unknown_tier_tenants = [
        {"account_active": True, "tier": "unsupported"} for _ in range(5)
    ]
    assert process_storage_tenants(unknown_tier_tenants, 0.0) == {
        "total_billed": 0.0,
        "status": "AUDIT_FLAGGED",
    }
    assert process_storage_tenants([], 0.0) == {
        "total_billed": 0.0,
        "status": "ZERO_USAGE",
    }


def test_replication_latency_alert_and_synced_paths():
    assert monitor_replication_latency([]) == "NO_DATA"
    assert monitor_replication_latency([[], [50, 201, 50]]) == "SYNCED"
    assert monitor_replication_latency([[201, 150, 201, 201]]) == "SYNC_LAG_ALERT"
